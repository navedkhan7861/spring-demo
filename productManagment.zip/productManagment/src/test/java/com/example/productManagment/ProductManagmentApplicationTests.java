package com.example.productManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
