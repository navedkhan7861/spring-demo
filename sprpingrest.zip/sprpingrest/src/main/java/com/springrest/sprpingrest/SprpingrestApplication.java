package com.springrest.sprpingrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprpingrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprpingrestApplication.class, args);
	}

}
